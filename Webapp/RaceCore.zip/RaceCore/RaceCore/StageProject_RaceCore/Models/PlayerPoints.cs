﻿namespace StageProject_RaceCore.Models
{
    public class PlayerPoints
    {
        public int Id { get; set; }

        public int GameSessionId { get; set; }
        public GameSession GameSession { get; set; } = null!;

        public int PlayerId { get; set; }
        public Player Player { get; set; } = null!;

        public int RaceId { get; set; }
        public Race Race { get; set; } = null!;

        public int? StageId { get; set; }
        public Stage? Stage { get; set; }

        public int? CyclistId { get; set; }
        public Cyclist? Cyclist { get; set; }

        public int Points { get; set; }
    }
}